
export default function magicArray(arr) {
	// Rock it!
}