
export default function transformArgumentsToArray(transformingFunction) {
	// go for it!!
}
