/* You can write anything in this file
IF you want to execute any code, run `npm start`. Node.js will execute code only in this file..
*/
import asynchronousDelay from "./1-asynchronous-delay"
import transformArgumentsToArray from "./2-wrap-it"
import magicArray from "3-array-magic"
import waitAMinute from "4-wait-a-minute"

console.log("Hello world")
