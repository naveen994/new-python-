
export default function waitAMinute() {
	// code goes here!
}