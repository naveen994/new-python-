
export default function asynchronousDelay(delay, callback) {
	// Your code here....
}
